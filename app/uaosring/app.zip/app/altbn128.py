from random import randint
#from past.builtins import long

from py_ecc import bn128
from py_ecc.bn128 import add, multiply, curve_order, G1
from py_ecc.bn128.bn128_field_elements import inv, field_modulus, FQ

from .utils import hashs, bytes_to_int, powmod

asint = lambda x: x.n if isinstance(x, FQ) else x

randsn = lambda: randint(1, curve_order - 1)
randsp = lambda: randint(1, field_modulus - 1)
sbmul = lambda s: multiply(G1, asint(s))
hashsn = lambda *x: hashs(*x) % curve_order
hashpn = lambda *x: hashsn(*[item.n for sublist in x for item in sublist])
hashp = lambda *x: hashs(*[item.n for sublist in x for item in sublist])
addmodn = lambda x, y: (x + y) % curve_order
addmodp = lambda x, y: (x + y) % field_modulus
mulmodn = lambda x, y: (x * y) % curve_order
mulmodp = lambda x, y: (x * y) % field_modulus
submodn = lambda x, y: (x - y) % curve_order
submodp = lambda x, y: (x - y) % field_modulus
invmodn = lambda x: inv(x, curve_order)
invmodp = lambda x: inv(x, field_modulus)
negp = lambda x: (x[0], -x[1])


def evalcurve(x):
	a = 5472060717959818805561601436314318772174077789324455915672259473661306552146
	beta = addmodp(mulmodp(mulmodp(x, x), x), 3)
	y = powmod(beta, a, field_modulus)
	return (beta, y)


def isoncurve(x, y):
	beta = addmodp(mulmodp(mulmodp(x, x), x), 3)
	return beta == mulmodp(y, y)


def hashtopoint(x):
	#assert isinstance(x, long)
	x = x % curve_order
	while True:
		beta, y = evalcurve(x)
		if beta == mulmodp(y, y):
			assert isoncurve(x, y)
			return FQ(x), FQ(y)
		x = addmodn(x, 1)
